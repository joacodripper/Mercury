# mercury-shop
Repositorio del proyecto de la asignatura de proyectos, corresponde a una página web orientada a la compraventa de productos usados, con opciones de regateo y compraventa, utilizando Django y PostgreSQL.
