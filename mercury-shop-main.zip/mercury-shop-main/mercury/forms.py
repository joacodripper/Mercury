from django import forms
from .models import *
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm, UserChangeForm

class CustomUserCreationForm(UserCreationForm):
    nombre = forms.CharField(widget=forms.TextInput(attrs={
       'placeholder': 'Nombre',
       'class': 'form-control',
       'type': 'text' 
    }), required=True)

    apellidoP = forms.CharField(widget=forms.TextInput(attrs={
       'placeholder': 'Apellido paterno',
       'class': 'form-control',
       'type': 'text' 
    }), required=True)

    apellidoM = forms.CharField(widget=forms.TextInput(attrs={
       'placeholder': 'Apellido materno',
       'class': 'form-control',
       'type': 'text'
    }), required=True)

    fecha_nacimiento = forms.DateField(
        widget=forms.TextInput(
            attrs={
                'placeholder': 'Fecha de nacimiento (dd-mm-aaaa)',  # Placeholder
                'class': 'form-control',  # Clase CSS para el campo
                'type': 'date'
            }
        ),
        validators=[validar_adulto],  # Asumiendo que 'validar_adulto' es un validador
        required=True  # El campo es obligatorio
    )


    region = forms.ModelChoiceField(
        queryset=region.objects.all(),
        empty_label="Seleccione una región",
        required=True,
        widget=forms.Select(attrs={
            'class': 'form-select'
        })
    )
    provincia = forms.ModelChoiceField(
        queryset=provincia.objects.all(),
        empty_label="Seleccione una provincia",
        required=True,
        widget=forms.Select(attrs={
            'class': 'form-select'
        })
    )
    comuna = forms.ModelChoiceField(
        queryset=comuna.objects.all(),
        empty_label="Seleccione una comuna",
        required=True,
        widget=forms.Select(attrs={
            'class': 'form-select'
        })
    )
    direccion = forms.CharField(widget=forms.TextInput(attrs={
       'placeholder': 'Dirección',
       'class': 'form-control' 
    }), required=True)
    
    correo = forms.CharField(widget=forms.EmailInput(attrs={
       'placeholder': 'Correo electrónico',
       'class': 'form-control' 
    }), required=True)

    password1 = forms.CharField(widget=forms.PasswordInput(attrs={
       'placeholder': 'Contraseña',
       'class': 'form-control' 
    }), required=True)

    password2 = forms.CharField(widget=forms.PasswordInput(attrs={
       'placeholder': 'Confirmar contraseña',
       'class': 'form-control' 
    }), required=True)

    class Meta:
        model = CustomUser
        fields = ['nombre', 'apellidoP', 'apellidoM', 'fecha_nac', 'comuna', 'direccion', 'correo', 'password1', 'password2']

class CustomUserAdminForm(UserChangeForm):
    # Personaliza el campo de fecha con un widget de tipo 'date' o un calendario visual.
    fecha_nac = forms.DateField(
        widget=forms.TextInput(
            attrs={'type': 'date', 'class': 'form-input border rounded px-4 py-2  text-light-900 dark:text-dark-900 mt-1 block w-full rounded-md bg-light-100'  # Clases de Tailwind
}
        ),
        required=True
    )

    class Meta:
        model = CustomUser
        fields = '__all__'  # O puedes especificar los campos que quieras mostrar
    
# Formulario de autenticación

class CustomAutenticationForm(AuthenticationForm):
    username = forms.EmailField(widget=forms.EmailInput(attrs={
        'placeholder': 'Correo',
        'class': 'form-control'
    }))

    password = forms.CharField(widget=forms.PasswordInput(attrs={
        'placeholder': 'Ingrese contraseña',
        'class': 'form-control'
    }))
     
# Formulario para la modificación de productos

from django import forms
from .models import producto, comision

class ProductoForm(forms.ModelForm):
    comision_porcentaje = forms.DecimalField(
        label="Comisión (%)",
        required=False,
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'readonly': 'readonly',
        }),
        help_text="Este es el porcentaje de comisión que aplica la plataforma."
    )

    class Meta:
        model = producto
        fields = [
            'nombre_producto', 'caracteristicas', 'subcategoria',
            'regateable', 'intercambiable', 'estado', 'precio_base',
            'imagen', 'video'
        ]
        widgets = {
            'nombre_producto': forms.TextInput(attrs={'class': 'form-control'}),
            'caracteristicas': forms.Textarea(attrs={'class': 'form-control'}),
            'subcategoria': forms.Select(attrs={'class': 'form-select'}),
            'regateable': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'intercambiable': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'estado': forms.Select(attrs={'class': 'form-select'}),
            'precio_base': forms.NumberInput(attrs={'class': 'form-control'}),
            'imagen': forms.ClearableFileInput(attrs={'class': 'form-control'}),
            'video': forms.ClearableFileInput(attrs={'class': 'form-control'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        comision_activa = comision.objects.filter(is_active=True).first()
        if comision_activa:
            self.fields['comision_porcentaje'].initial = comision_activa.porcentaje

    def clean_precio_base(self):
        precio_base = self.cleaned_data.get('precio_base')
        if precio_base < 0:
            raise forms.ValidationError("El precio base no puede ser negativo.")
        if precio_base < 5000:
            raise forms.ValidationError("El valor mínimo es de $5.000 pesos.")  
        return precio_base

