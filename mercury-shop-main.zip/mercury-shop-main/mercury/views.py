from django.http import JsonResponse, HttpResponse
from django.urls import reverse, reverse_lazy
from django.shortcuts import render, redirect, get_object_or_404
from .forms import *
from django.contrib.auth import login, authenticate, logout
from .models import *
from django.contrib.sites.shortcuts import get_current_site
from django.template.loader import render_to_string
from django.utils.http import urlsafe_base64_decode, urlsafe_base64_encode
from django.utils.encoding import force_bytes, force_str
from .tokens import account_activation_token
from django.core.mail import EmailMessage
from django.contrib import messages
from django.contrib.auth import get_user_model, login
from django.views.generic.edit import CreateView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic.edit import UpdateView
from django.views.generic.list import ListView
from django.contrib.auth.decorators import login_required, user_passes_test
from django.core.paginator import Paginator
from transbank.webpay.webpay_plus.transaction import Transaction
from transbank.common.integration_type import IntegrationType
from transbank.common.options import WebpayOptions
from transbank.webpay.webpay_plus.transaction import IntegrationApiKeys, IntegrationCommerceCodes
from collections import defaultdict
from django.core.mail import send_mail
from django.template.loader import render_to_string
from django.db.models import Sum, Count
from django.db.models.functions import Coalesce
from django.core.serializers.json import DjangoJSONEncoder
import json
from decimal import Decimal
import csv
from django.utils.dateformat import format
from django.utils.formats import localize

# Create your views here.

def redirectHome(request):
    return redirect('mercury:home')

def index(request):
    return render(request, "pagina/index.html") 

@login_required(login_url='/debes-logueate')
def home(request):
    # Obtener los últimos productos publicados
    productos = producto.objects.filter(publicado=True, activado=True).order_by('-fecha_registro')[:8]
    
    return render(request, 'pagina/home.html', {'user': request.user, 'productos': productos})

def register(request):
    if request.method == 'POST':
        print(request.POST)
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.comuna = form.cleaned_data['comuna']
            user.is_active = False
            user.save()
            
            current_site = get_current_site(request)
            mail_subject = "Activa tu cuenta con el correo que hemos enviado."
            message = render_to_string("cuentas/validacion_correo.html",{"user":user, "domain": current_site.domain, "uid":urlsafe_base64_encode(force_bytes(user.pk)), "token":account_activation_token.make_token(user)})
            to_email = form.cleaned_data.get("correo")
            email = EmailMessage(
                mail_subject, message, to=[to_email]
            )
            email.send()
            messages.success(request, "Por favor, revisa tu correo para completar el registro.")
            return redirect("/")
        else:
            print(form.errors)
    else:
        form = CustomUserCreationForm()  # Para solicitudes GET o cuando el formulario no es válido

    # Renderiza la plantilla en todos los casos
    return render(request, "cuentas/registro.html", {'form': form})

def activate(request, uidb64, token):
    User = get_user_model()
    try:
        uid = force_str(urlsafe_base64_decode(uidb64)) 
        user = User.objects.get(pk=uid)
    except (TypeError, ValueError, OverflowError, User.DoesNotExist):
        user = None

    if user is not None and account_activation_token.check_token(user,token) and user.is_active is False:   
    # Confirmar que el usuario no está nulo, que está recibiendo el token asociado al usuario y si el usuario 
    # no está activo, de forma que no se desplieguen los mensajes para usuarios con cuentas ya activadas.
        user.is_active = True
        user.save()
        
        messages.success(request, "Tu cuenta ha sido exitosamente activada!")
        return redirect(reverse("mercury:Iniciar sesión"))
    else:
        messages.error(request, "El enlace de activación es inválido o ha expirado.")
    return redirect("mercury:Iniciar sesión")

def user_login(request):
    if request.method == 'POST':
        form = CustomAutenticationForm(request, request.POST)
        if form.is_valid():
            email = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, correo=email, password=password)

            if user is not None:
                login(request, user)
                return redirect('mercury:home')
    else:
        form = CustomAutenticationForm()
    return render(request, 'cuentas/login.html', {'form': form})

def user_logout(request):
    logout(request)
    return redirect('mercury:Inicio')

# Funcionamiento de página

# Producto

from django.contrib import messages

class ProductoCreateView(LoginRequiredMixin, CreateView):
    model = producto
    form_class = ProductoForm
    template_name = "producto/crear_producto.html"
    success_url = reverse_lazy('mercury:listar_productos')  # Cambia por la URL de listar productos

    def form_valid(self, form):
        form.instance.usuario = self.request.user
        # Calcular comisión y precio final
        comision_activa = comision.objects.filter(is_active=True).first()
        if comision_activa:
            form.instance.comision = comision_activa
            form.instance.precio_final = form.instance.precio_base + (form.instance.precio_base * (comision_activa.porcentaje / 100))
        
        # Agregar mensaje de éxito
        messages.success(self.request, '¡Producto registrado exitosamente!')

        return super().form_valid(form)

class ProductoUpdateView(LoginRequiredMixin, UpdateView):
    model = producto
    form_class = ProductoForm
    template_name = "producto/editar_producto.html"
    success_url = reverse_lazy('mercury:listar_productos')  # Cambia por la URL de listar productos
    login_url = "mercury:Iniciar sesión"

    def form_valid(self, form):
        form.instance.usuario = self.request.user
        # Si necesitas hacer algún cálculo adicional, como calcular el precio final o comisión
        comision_activa = comision.objects.filter(is_active=True).first()
        if comision_activa:
            form.instance.comision = comision_activa
            form.instance.precio_final = form.instance.precio_base + (form.instance.precio_base * (comision_activa.porcentaje / 100))

        # Mensaje de éxito al actualizar el producto
        messages.success(self.request, 'Datos modificados exitosamente.')
        
        return super().form_valid(form)
    
def eliminar_producto(request, producto_id):
    producto_obj = get_object_or_404(producto, id=producto_id, usuario=request.user)

    if request.method == "POST":
        producto_obj.delete()
        messages.success(request, "El producto ha sido eliminado exitosamente.")
        return redirect("mercury:listar_productos")

    messages.error(request, "No se pudo eliminar el producto.")
    return redirect("mercury:listar_productos")

class ProductoListView(LoginRequiredMixin, ListView):
    model = producto
    template_name = "producto/inventario.html"
    context_object_name = "productos"

    def get_queryset(self):
        # Filtrar productos por el usuario logueado y por el estado activo
        return self.model.objects.filter(usuario=self.request.user, activado=True)

def toggle_publicado(request, producto_id):
    producto_obj = get_object_or_404(producto, id=producto_id, usuario=request.user)

    # Cambiar el estado de 'publicado'
    producto_obj.publicado = not producto_obj.publicado
    producto_obj.save()

    # Mensaje de éxito
    if producto_obj.publicado:
        messages.success(request, "El producto ha sido publicado exitosamente.")
    else:
        messages.success(request, "El producto ha sido despublicado exitosamente.")

    return redirect('mercury:listar_productos')

def desactivar_producto(request, producto_id):
    Producto = get_object_or_404(producto, id=producto_id)
    
    # Desactivar el producto en lugar de eliminarlo
    Producto.activado = False
    Producto.save()
    
    # Agregar mensaje de éxito
    messages.success(request, "El producto ha sido eliminado correctamente.")

    # Redirigir a la lista de productos
    return redirect('mercury:listar_productos')

def debes_loguearte(request):
    return render(request, "producto/must_login.html", {
        'mensaje' : 'Debes iniciar sesión para poder acceder a esta página',
    })

# Catalogo

def catalogo(request):
    # Filtrar productos publicados y activados
    if request.user.is_authenticated:
        # Excluir los productos publicados por el usuario actual si está autenticado
        productos_publicados = producto.objects.filter(publicado=True, activado=True).exclude(usuario=request.user)
    else:
        # Mostrar todos los productos publicados y activados para usuarios no autenticados
        productos_publicados = producto.objects.filter(publicado=True, activado=True)
    
    # Paginación: 9 productos por página
    paginator = Paginator(productos_publicados, 8)
    page_number = request.GET.get('page')
    productos_page = paginator.get_page(page_number)

    context = {
        'productos': productos_page,
    }
    return render(request, 'catalogo/catalogo.html', context)

def producto_detalle(request, product_id):
    # Obtener el producto con el id proporcionado
    productoobj = get_object_or_404(producto, id=product_id)
    return render(request, 'catalogo/producto_detalle.html', {
        'producto': productoobj,
    })

def about(request):
    return render(request, 'pagina/about.html')

def popularitems(request):
    return render(request, 'pagina/popularitems.html')

def newarrivals(request):
    return render(request, 'pagina/newarrivals.html')

# Carro de compra

@login_required
def agregar_al_carrito(request, producto_id):
    try:
        producto_obj = producto.objects.get(id=producto_id, disponible=True, cantidad__gt=0)
    except producto.DoesNotExist:
        return JsonResponse({'error': 'Producto no disponible o sin existencias'}, status=400)

    carrito, created = Carrito.objects.get_or_create(usuario=request.user)
    producto_en_carrito, creado = ProductoCarrito.objects.get_or_create(
        carrito=carrito,
        producto=producto_obj,
        defaults={'cantidad': 1, 'precio': producto_obj.precio_final}
    )

    if not creado:
        if producto_en_carrito.cantidad < producto_obj.cantidad:
            producto_en_carrito.cantidad += 1
            producto_en_carrito.save()
        else:
            return JsonResponse({'error': 'No hay suficientes existencias'}, status=400)

    return JsonResponse({'message': 'Producto agregado al carrito', 'cantidad': producto_en_carrito.cantidad}, status=200)


@login_required
def sincronizar_carrito(request):
    carrito = Carrito.objects.filter(usuario=request.user).first()
    if carrito:
        productos_a_eliminar = []
        for item in carrito.productos.all():
            if item.producto.cantidad == 0:
                productos_a_eliminar.append(item)

        # Eliminar productos sin existencias del carrito
        ProductoCarrito.objects.filter(id__in=[p.id for p in productos_a_eliminar]).delete()

    return JsonResponse({'message': 'Carrito sincronizado'}, status=200)

@login_required
def cantidad_productos_carrito(request):
    carrito = Carrito.objects.filter(usuario=request.user).first()
    cantidad = sum([item.cantidad for item in carrito.productos.all()]) if carrito else 0
    return JsonResponse({'cantidad': cantidad})

@login_required
def vista_carrito(request):
    carrito = Carrito.objects.filter(usuario=request.user).first()
    productos_carrito = carrito.productos.all() if carrito else []

    # Verificar disponibilidad de productos
    for item in productos_carrito:
        if item.producto.cantidad == 0:
            item.delete()  # Eliminar productos sin existencias

      # Formatear el precio de cada producto con separadores de miles
    for item in productos_carrito:
        item.precio_formateado = f"{int(item.precio):,}".replace(",", ".")  # Formato con separadores de miles        

    total = sum(item.precio * item.cantidad for item in productos_carrito)
    total_formateado = f"{int(total):,}".replace(",", ".")  # Formato con separadores de miles

    return render(request, 'carrito/carrito.html', {
        'productos_carrito': productos_carrito,
        'total': total_formateado,
    })


@login_required
def eliminar_producto_carrito(request, producto_carrito_id):
    try:
        producto_carrito = ProductoCarrito.objects.get(id=producto_carrito_id, carrito__usuario=request.user)
        producto_carrito.delete()
        return JsonResponse({'message': 'Producto eliminado exitosamente.'})
    except ProductoCarrito.DoesNotExist:
        return JsonResponse({'error': 'El producto no existe o no está en tu carrito.'}, status=400)
    

# PAGO TRANSBANK

@login_required
def iniciar_pago(request):
    carrito = Carrito.objects.filter(usuario=request.user).first()
    if not carrito or not carrito.productos.exists():
        messages.error(request, "Tu carrito está vacío.")
        return redirect('mercury:vista_carrito')

    # Calcular el total
    total = sum(item.cantidad * item.precio for item in carrito.productos.all())

    # Crear transacción con Transbank
    transaction = Transaction(WebpayOptions(
        commerce_code=IntegrationCommerceCodes.WEBPAY_PLUS,  # Código de comercio correcto
        api_key=IntegrationApiKeys.WEBPAY,  # API Key correcta
        integration_type=IntegrationType.TEST  # Modo de integración
    ))
    response = transaction.create(
        buy_order=f"order-{request.user.id}-{int(now().timestamp())}",
        session_id=str(request.user.id),
        amount=total,
        return_url=request.build_absolute_uri(reverse('mercury:confirmar_pago'))
    )

    # Guardar la URL de pago y redirigir
    return redirect(response['url'] + '?token_ws=' + response['token'])

@login_required
def confirmar_pago(request):
    token_ws = request.GET.get('token_ws')

    if not token_ws:
        messages.error(request, "Token no recibido desde Transbank.")
        return redirect('mercury:vista_carrito')

    transaction = Transaction(WebpayOptions(
        commerce_code=IntegrationCommerceCodes.WEBPAY_PLUS,
        api_key=IntegrationApiKeys.WEBPAY,
        integration_type=IntegrationType.TEST
    ))
    response = transaction.commit(token_ws)

    if response['status'] == 'AUTHORIZED':
        carrito = Carrito.objects.filter(usuario=request.user).first()
        ventas_por_vendedor = defaultdict(list)
        detalles_venta = []

        for item in carrito.productos.all():
            venta = Venta.objects.create(
                comprador=request.user,
                vendedor=item.producto.usuario,
                producto=item.producto,
                cantidad=item.cantidad,
                total=item.precio * item.cantidad,
            )
            detalles_venta.append(venta)
            ventas_por_vendedor[item.producto.usuario].append(venta)

            # Reducir el stock del producto
            item.producto.cantidad -= item.cantidad
            if item.producto.cantidad == 0:
                item.producto.activado = False
            item.producto.save()

        # Limpiar el carrito
        carrito.productos.all().delete()

        # Enviar email al comprador con los códigos de retiro
        email_subject = "Confirmación de compra - Códigos de retiro"
        email_body = render_to_string('email/codigos_retiro.html', {'ventas': detalles_venta, 'usuario': request.user})
        send_mail(
            email_subject,
            email_body,
            'noreply@mercury.com',
            [request.user.correo],
            fail_silently=False,
        )

        # Enviar email a cada vendedor con los códigos de retiro correspondientes
        for vendedor, ventas in ventas_por_vendedor.items():
            email_subject_vendedor = f"Códigos de retiro para tus productos vendidos"
            email_body_vendedor = render_to_string('email/codigos_retiro_vendedor.html', {'ventas': ventas, 'vendedor': vendedor})
            send_mail(
                email_subject_vendedor,
                email_body_vendedor,
                'noreply@mercury.com',
                [vendedor.correo],
                fail_silently=False,
            )

        messages.success(request, "Pago realizado con éxito. Revisa tu correo para los códigos de retiro.")
        return render(request, 'carrito/detalle_compra.html', {
            'ventas': detalles_venta,
            'total_pagado': sum(venta.total for venta in detalles_venta)
        })
    else:
        messages.error(request, "El pago no fue exitoso. Intenta nuevamente.")
        return redirect('mercury:vista_carrito')


@login_required
def confirmar_entrega(request):
    if request.method == "POST":
        codigo_retiro = request.POST.get('codigo_retiro')
        try:
            # Busca la venta con el código y que corresponda al vendedor autenticado
            venta = Venta.objects.get(codigo_retiro=codigo_retiro, vendedor=request.user)
            
            if venta.confirmado:
                messages.warning(request, f"La entrega del producto '{venta.producto.nombre_producto}' ya fue confirmada.")
            else:
                venta.confirmado = True
                venta.save()
                messages.success(request, f"Entrega confirmada para el producto '{venta.producto.nombre_producto}'.")
        except Venta.DoesNotExist:
            messages.error(request, "Código de retiro inválido o no autorizado.")
    
    return render(request, 'carrito/confirmar_entrega.html')

# Reportes

@user_passes_test(lambda u: u.is_superuser)
def reportes(request):
    # Filtros iniciales
    ventas = Venta.objects.all()
    region1 = request.GET.get('region')
    comuna1 = request.GET.get('comuna')
    mes = request.GET.get('mes')
    año = request.GET.get('año')
    semana = request.GET.get('semana')

    # Aplicar filtros
    if region1:
        ventas = ventas.filter(producto__usuario__comuna__provincia__region__id=region1)
    if comuna1:
        ventas = ventas.filter(producto__usuario__comuna__id=comuna1)
    if mes:
        ventas = ventas.filter(fecha_venta__month=mes)
    if año:
        ventas = ventas.filter(fecha_venta__year=año)
    if semana:
        ventas = ventas.filter(fecha_venta__week=semana)

    # Estadísticas
    total_ventas = ventas.aggregate(total=Coalesce(Sum('total'), Decimal('0')))['total']
    cantidad_ventas = ventas.count()
    comision = Decimal('0.18')  # Comisión del 18%
    ganancias = total_ventas * comision

    # Formatear valores
    total_ventas_formateado = f"{int(total_ventas):,}".replace(",", ".")
    ganancias_formateadas = f"{int(ganancias):,}".replace(",", ".")

    # Datos para la tabla
    ventas_por_producto = ventas.values('producto__nombre_producto').annotate(
        total_vendido=Sum('total'),
        cantidad_vendida=Count('id')
    ).order_by('-total_vendido')

    # Formatear totales por producto
    for venta in ventas_por_producto:
        venta['total_vendido_formateado'] = f"{int(venta['total_vendido']):,}".replace(",", ".")

    # Gráficos
    productos = [venta['producto__nombre_producto'] for venta in ventas_por_producto]
    cantidades = [venta['cantidad_vendida'] for venta in ventas_por_producto]

    # Regiones y comunas para el filtro
    regiones = region.objects.all()
    comunas = comuna.objects.all()

    # Meses
    meses = [
        {'numero': 1, 'nombre': 'Enero'},
        {'numero': 2, 'nombre': 'Febrero'},
        {'numero': 3, 'nombre': 'Marzo'},
        {'numero': 4, 'nombre': 'Abril'},
        {'numero': 5, 'nombre': 'Mayo'},
        {'numero': 6, 'nombre': 'Junio'},
        {'numero': 7, 'nombre': 'Julio'},
        {'numero': 8, 'nombre': 'Agosto'},
        {'numero': 9, 'nombre': 'Septiembre'},
        {'numero': 10, 'nombre': 'Octubre'},
        {'numero': 11, 'nombre': 'Noviembre'},
        {'numero': 12, 'nombre': 'Diciembre'}
    ]

    context = {
        'ventas': ventas,
        'total_ventas': total_ventas_formateado,
        'ganancias': ganancias_formateadas,
        'cantidad_ventas': cantidad_ventas,
        'ventas_por_producto': ventas_por_producto,
        'productos': productos,
        'cantidades': cantidades,
        'regiones': regiones,
        'comunas': comunas,
        'meses': meses,
    }

    return render(request, 'reportes/reportes.html', context)

@user_passes_test(lambda u: u.is_superuser)
def exportar_datos(request):
    # Filtrar las ventas según los parámetros en el request
    ventas = Venta.objects.all()
    region_id = request.GET.get('region')
    comuna_id = request.GET.get('comuna')
    mes = request.GET.get('mes')
    año = request.GET.get('año')

    if region_id:
        ventas = ventas.filter(producto__usuario__comuna__provincia__region__id=region_id)
    if comuna_id:
        ventas = ventas.filter(producto__usuario__comuna__id=comuna_id)
    if mes:
        ventas = ventas.filter(fecha_venta__month=mes)
    if año:
        ventas = ventas.filter(fecha_venta__year=año)

    # Crear el archivo CSV
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="reporte_ventas.csv"'

    writer = csv.writer(response)
    writer.writerow(['Producto', 'Vendedor', 'Comprador', 'Cantidad', 'Total', 'Fecha de Venta'])
    for venta in ventas:
        writer.writerow([
            venta.producto.nombre_producto,
            f"{venta.vendedor.nombre} {venta.vendedor.apellidoP}",
            f"{venta.comprador.nombre} {venta.comprador.apellidoP}",
            venta.cantidad,
            f"{int(venta.total):,}".replace(",", "."),
            venta.fecha_venta.strftime('%d-%m-%Y'),
        ])

    return response

# Obtencion de datos para

def get_provincias(request): # Ajax, carga los datos de provincias acorde a las regiones
    region_id = request.GET.get('region_id')
    provincias = provincia.objects.filter(region_id=region_id)
    data = [{'id': p.id, 'nombreProvincia': p.nombreProvincia} for p in provincias]
    return JsonResponse(data, safe=False)

def get_comunas(request):
    provincia_id = request.GET.get('provincia_id') # Ajax, carga los datos de comunas acorde a las provincias
    comunas = comuna.objects.filter(provincia_id=provincia_id)
    data = [{'id': c.id, 'nombreComuna': c.nombreComuna} for c in comunas]
    return JsonResponse(data, safe=False)

