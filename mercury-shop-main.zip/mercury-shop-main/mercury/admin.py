from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import CustomUser
from .forms import *
from django.db.models import Count
import csv
from django.http import HttpResponse

@admin.register(CustomUser)
class CustomUserAdmin(UserAdmin):
    form = CustomUserAdminForm

    # Campos que se mostrarán en la lista de usuarios
    list_display = ('correo', 'nombre', 'apellidoP', 'apellidoM', 'fecha_nac', 'comuna_nombre', 'is_active', 'is_staff')

    # Campos para ordenar
    ordering = ('correo',)
    
    # Campos para búsqueda
    search_fields = ('correo', 'nombre', 'apellidoP', 'apellidoM')

    # Campos para el filtrado rápido
    list_filter = ('is_active', 'is_staff', 'comuna')

    # Vista de edición de usuario
    fieldsets = (
        (None, {'fields': ('correo', 'password')}),
        ('Información personal', {'fields': ('nombre', 'apellidoP', 'apellidoM', 'fecha_nac', 'direccion', 'comuna')}),
        ('Permisos', {'fields': ('is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions')}),
        ('Fechas importantes', {'fields': ('last_login',)}),
    )

    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('correo', 'password1', 'password2', 'nombre', 'apellidoP', 'apellidoM', 'fecha_nac', 'direccion', 'comuna'),
        }),
    )

    def comuna_nombre(self, obj):
        return obj.comuna.nombreComuna if obj.comuna else 'No asignada'
    comuna_nombre.short_description = 'Comuna'

@admin.register(producto)
class ProductoAdmin(admin.ModelAdmin):
    list_display = (
        'nombre_producto', 'usuario', 'subcategoria_nombre', 'comision_porcentaje', 'precio_base', 'precio_final', 'cantidad', 'disponible', 'activado',  'publicado', 'fecha_registro'
    )

    # Filtros para la vista de administración
    list_filter = ('disponible', 'activado', 'subcategoria', 'comision')

    # Método para mostrar el nombre de la subcategoría
    def subcategoria_nombre(self, obj):
        return obj.subcategoria.nombre_subcategoria if obj.subcategoria else 'Sin subcategoría'
    subcategoria_nombre.short_description = 'Subcategoría'

    # Método para mostrar el porcentaje de la comisión
    def comision_porcentaje(self, obj):
        return f"{obj.comision.porcentaje}%" if obj.comision else 'No aplicada'
    comision_porcentaje.short_description = 'Comisión (%)'

    # Método para formatear el precio
    def precio_formateado(self, obj):
        return f"{int(obj.precio_final):,}".replace(",", ".")
    precio_formateado.short_description = 'Precio Final'

    # Campos de búsqueda
    search_fields = ('nombre_producto', 'usuario__correo', 'subcategoria__nombre_subcategoria')

    # Campos para ordenar
    ordering = ('fecha_registro',)

@admin.register(categoria)
class CategoriaAdmin(admin.ModelAdmin):
    list_display = ('nombreCategoria', 'fecha_registro')

    # Filtros rápidos
    list_filter = ('fecha_registro',)

    # Búsqueda por nombre
    search_fields = ('nombreCategoria',)

    # Ordenar por fecha
    ordering = ('fecha_registro',)

@admin.register(subcategoria)
class SubcategoriaAdmin(admin.ModelAdmin):
    list_display = ('nombre_subcategoria', 'categoria_nombre')

    # Método para obtener el nombre de la categoría
    def categoria_nombre(self, obj):
        return obj.categoria.nombreCategoria if obj.categoria else 'Sin categoría'
    categoria_nombre.short_description = 'Categoría'

    # Filtros
    list_filter = ('categoria',)

    # Búsqueda por nombre de subcategoría
    search_fields = ('nombre_subcategoria',)

    # Ordenar por nombre
    ordering = ('nombre_subcategoria',)

@admin.register(estadoProducto)
class EstadoProductoAdmin(admin.ModelAdmin):
    list_display = ('nombreEstado',)

    # Búsqueda por nombre
    search_fields = ('nombreEstado',)

    # Ordenar por nombre
    ordering = ('nombreEstado',)

@admin.register(comision)
class ComisionAdmin(admin.ModelAdmin):
    list_display = ('porcentaje', 'is_active')

    # Filtros rápidos
    list_filter = ('is_active',)

    # Búsqueda por porcentaje
    search_fields = ('porcentaje',)

    # Ordenar por porcentaje
    ordering = ('porcentaje',)

@admin.register(region)
class RegionAdmin(admin.ModelAdmin):
    list_display = ('nombreRegion', 'abreviatura')

    # Filtros
    list_filter = ('nombreRegion',)

    # Búsqueda por nombre
    search_fields = ('nombreRegion',)

    # Ordenar por nombre
    ordering = ('nombreRegion',)

@admin.register(provincia)
class ProvinciaAdmin(admin.ModelAdmin):
    list_display = ('nombreProvincia', 'region_nombre')

    # Método para obtener el nombre de la región
    def region_nombre(self, obj):
        return obj.region.nombreRegion if obj.region else 'Sin región'
    region_nombre.short_description = 'Región'

    # Filtros
    list_filter = ('region',)

    # Búsqueda por nombre
    search_fields = ('nombreProvincia',)

    # Ordenar por nombre
    ordering = ('nombreProvincia',)

@admin.register(comuna)
class ComunaAdmin(admin.ModelAdmin):
    list_display = ('nombreComuna', 'provincia_nombre')

    # Método para obtener el nombre de la provincia
    def provincia_nombre(self, obj):
        return obj.provincia.nombreProvincia if obj.provincia else 'Sin provincia'
    provincia_nombre.short_description = 'Provincia'

    # Filtros
    list_filter = ('provincia',)

    # Búsqueda por nombre
    search_fields = ('nombreComuna',)

    # Ordenar por nombre
    ordering = ('nombreComuna',)

@admin.register(Venta)
class VentaAdmin(admin.ModelAdmin):
    list_display = ('producto', 'comprador', 'vendedor', 'cantidad', 'total', 'fecha_venta', 'codigo_retiro', 'confirmado')
    list_filter = ('confirmado', 'fecha_venta', 'producto')  # Filtros en la barra lateral
    search_fields = ('producto__nombre_producto', 'comprador__nombre', 'vendedor__nombre', 'codigo_retiro')  # Barra de búsqueda
    ordering = ('-fecha_venta',)  # Ordenar por fecha de venta descendente

admin.site.register(Carrito)
admin.site.register(ProductoCarrito)
admin.site.register(Regateo)
admin.site.register(Intercambio)


