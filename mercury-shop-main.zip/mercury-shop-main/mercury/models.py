from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from .validators import *
from django.conf import settings
from django.utils.timezone import now
from uuid import uuid4


# Create your models here.

class region(models.Model):
    nombreRegion = models.CharField(max_length=64)
    abreviatura = models.CharField(max_length=4, blank=False)

    def __str__(self):
        return self.nombreRegion

class provincia(models.Model):
    region = models.ForeignKey(region, on_delete=models.CASCADE)
    nombreProvincia = models.CharField(max_length=64)

    def __str__(self):
        return self.nombreProvincia

class comuna(models.Model):
    provincia = models.ForeignKey(provincia, on_delete=models.CASCADE)
    nombreComuna = models.CharField(max_length=64)

    def __str__(self):
        return self.nombreComuna

class CustomUserManager(BaseUserManager):
    def create_user(self, correo, password=None, **extra_fields):
        if not correo:
            raise ValueError('No ha ingresado una dirección válida de correo.')
        
        correo = self.normalize_email(correo)
        user = self.model(correo=correo, **extra_fields)
        user.set_password(password)
        user.save(using=self._db) # Guarda el usuario en db

        return user
    
    def create_superuser(self, correo, password, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)

        return self.create_user(correo, password, **extra_fields)


class CustomUser(AbstractBaseUser, PermissionsMixin):   # Definir los campos que queremos que tenga el usuario (en ejemplo: fname, lname, email, id_estudiante, pass1 y pass2)
    nombre = models.CharField(max_length=50, validators=[validar_nombre_largo], blank=False)
    apellidoP = models.CharField(max_length=50, validators=[validar_apellido_minimo], blank=False, verbose_name="Apellido paterno")
    apellidoM = models.CharField(max_length=50, validators=[validar_apellido_minimo], blank=False, verbose_name="Apellido materno")    
    fecha_nac = models.DateField(validators=[validar_adulto, validar_edad_maxima], null=True, blank=True, verbose_name="Fecha de nacimiento")
    comuna = models.ForeignKey(comuna, on_delete=models.RESTRICT, null=True)
    direccion = models.CharField(max_length=150, verbose_name="Dirección")
    correo = models.EmailField(unique=True)

    is_active = models.BooleanField(default=True, verbose_name="Activo")
    is_staff = models.BooleanField(default=False, verbose_name="Staff")

    objects = CustomUserManager()

    USERNAME_FIELD = 'correo'
    REQUIRED_FIELDS = []

    class Meta:
        verbose_name = 'Usuario'
        verbose_name_plural = 'Usuarios'

    def __str__(self):
        return self.correo

class categoria(models.Model):
    nombreCategoria = models.CharField(max_length=200, unique=True, null=True)
    fecha_registro = models.DateTimeField(auto_now_add=True) # auto_now_add -> Por default se asigna la fecha

    def __str__(self):
        return self.nombreCategoria
    
class subcategoria(models.Model):
    categoria = models.ForeignKey(categoria, on_delete=models.CASCADE, related_name="subcategorias")
    nombre_subcategoria = models.CharField(max_length=255, verbose_name="Nombre de la Subcategoría", unique=True)

    def __str__(self):
        return f"{self.categoria.nombreCategoria} - {self.nombre_subcategoria}"
    
class estadoProducto(models.Model):
    nombreEstado = models.CharField(max_length=50, unique=True, verbose_name="Estado del producto")

    def __str__(self):
        return self.nombreEstado
    
class comision(models.Model):
    porcentaje = models.DecimalField(max_digits=5, decimal_places=2, help_text="Porcentaje de la comisión (e.g)., 15.00 para 15%")
    is_active = models.BooleanField(default=False, help_text="Indica si esta comisión esta actualmente vigente.")

    def get_active_comission(cls):
        return cls.objects.filter(is_active=True).first()
    
    def __str__(self):
        return f"{self.porcentaje}% {'Activa)' if self.is_active else ''}"
    
class producto(models.Model):
    usuario = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="productos", verbose_name="Usuario", null=True)
    nombre_producto = models.CharField(max_length=255, verbose_name="Nombre del Producto", null=True)
    caracteristicas = models.TextField(blank=True, null=True, verbose_name="Características")
    subcategoria = models.ForeignKey(subcategoria, on_delete=models.CASCADE, related_name="productos", null=True)
    regateable = models.BooleanField(default=False, verbose_name="¿Regateable?")
    intercambiable = models.BooleanField(default=False, verbose_name="¿Intercambiable?")
    estado = models.ForeignKey(estadoProducto, on_delete=models.SET_NULL, null=True, verbose_name="Estado del Producto")
    fecha_registro = models.DateField(auto_now=True, verbose_name="Fecha de registro")
    disponible = models.BooleanField(default=True)
    activado = models.BooleanField(default=True)
    publicado = models.BooleanField(default=False)
    precio_base = models.DecimalField(max_digits=10, decimal_places=0, default=0.0, verbose_name="Precio base")
    cantidad = models.PositiveBigIntegerField(default=1, verbose_name="Cantidad")
    comision = models.ForeignKey(comision, on_delete=models.SET_NULL, null=True, blank=True, verbose_name="Comisión aplicada")
    precio_final = models.DecimalField(max_digits=10, decimal_places=0  , default=0.0, verbose_name="Precio final")
    
    # Campos para la imagen y el video
    
    imagen = models.ImageField(upload_to='productos/imagenes/', default='mercury\static\imagenes\default.jpg' ,verbose_name="Imagen del Producto")
    video = models.FileField(upload_to='productos/videos/', blank=True, null=True, verbose_name="Video del Producto")

    fecha_actualizacion = models.DateTimeField(auto_now=True, verbose_name="Última actualización")
    
    def calcular_comision( self):
        """
        Calcula la comisión aplicable al precio base.
        """

        if self.comision:
            return self.precio_base * (self.comision.porcentaje / 100)
        return 0
    
    def calcular_precio_final(self):
        """
        Calcula el precio final sumando la comisión al precio base.
        """
        if self.comision:
            comision_valor = self.precio_base * (self.comision.porcentaje / 100)
            self.precio_final = self.precio_base + comision_valor
        else:
            self.precio_final = self.precio_base
        return self.precio_final
    
    def __str__(self):
        return f"{self.usuario} - {self.nombre_producto} ({self.cantidad})"
    
    def precio_formateado(self):
        return f"{int(self.precio_final):,}".replace(",", ".")

class Carrito(models.Model):
    usuario = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    fecha_creacion = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Carrito de {self.usuario.nombre}"

class ProductoCarrito(models.Model):
    carrito = models.ForeignKey(Carrito, related_name='productos', on_delete=models.CASCADE)
    producto = models.ForeignKey(producto, on_delete=models.CASCADE)
    cantidad = models.PositiveIntegerField(default=1)
    precio = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return f"{self.cantidad} x {self.producto.nombre_producto} en el carrito"
    
class Regateo(models.Model):
    producto = models.ForeignKey(producto, on_delete=models.CASCADE)
    usuario_ofertante = models.ForeignKey(settings.AUTH_USER_MODEL, related_name='ofertas', on_delete=models.CASCADE)
    oferta = models.DecimalField(max_digits=10, decimal_places=2)
    estado = models.CharField(
        max_length=20, 
        choices=[('pendiente', 'Pendiente'), ('aceptado', 'Aceptado'), ('rechazado', 'Rechazado')],
        default='pendiente'
    )
    fecha_oferta = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Oferta de {self.usuario_ofertante.nombre} para {self.producto.nombre_producto}"
    
class Intercambio(models.Model):
    producto_ofrecido = models.ForeignKey(producto, related_name='producto_ofrecido', on_delete=models.CASCADE)
    producto_deseado = models.ForeignKey(producto, related_name='producto_deseado', on_delete=models.CASCADE)
    usuario_ofreciente = models.ForeignKey(settings.AUTH_USER_MODEL, related_name='intercambios_ofrecidos', on_delete=models.CASCADE, default=1)
    usuario_receptor = models.ForeignKey(settings.AUTH_USER_MODEL, related_name='intercambios_recibidos', on_delete=models.CASCADE, default=2)
    estado = models.CharField(
        max_length=20,
        choices=[('pendiente', 'Pendiente'), ('aceptado', 'Aceptado'), ('rechazado', 'Rechazado')],
        default='pendiente'
    )
    fecha_intercambio = models.DateTimeField(auto_now = True)

    def __str__(self):
        return f"Intercambio de {self.usuario_ofreciente.nombre} con {self.usuario_receptor.nombre}"

from uuid import uuid4

class Venta(models.Model):
    comprador = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='compras', null=True)
    vendedor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='ventas', null=True)
    producto = models.ForeignKey(producto, on_delete=models.CASCADE)
    cantidad = models.PositiveIntegerField()
    total = models.DecimalField(max_digits=10, decimal_places=2)
    fecha_venta = models.DateTimeField(auto_now_add=True)
    codigo_retiro = models.CharField(max_length=36, default=uuid4, blank=True)
    confirmado = models.BooleanField(default=False)

    def save(self, *args, **kwargs):
        if not self.codigo_retiro:
            while True:
                codigo = str(uuid4())
                if not Venta.objects.filter(codigo_retiro=codigo).exists():
                    self.codigo_retiro = codigo
                    break
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.producto.nombre_producto} (x{self.cantidad}) - Compra de {self.comprador.nombre} a {self.vendedor.nombre}"

