from datetime import date
from django.core.exceptions import ValidationError

def validar_adulto(value):
    """
    Valida que la persona que se está registrando sea mayor de 18 años.
    """
    today = date.today()
    age = today.year - value.year - ((today.month, today.day) < (value.month, value.day)) 
    if age < 18:
        raise ValidationError("Debes ser mayor de 18 años para poder registrarte.")
    
def validar_edad_maxima(value):
    # Obtiene la fecha actual
    hoy = date.today()
    
    # Calcula la edad a partir de la fecha de nacimiento ingresada
    edad = hoy.year - value.year - ((hoy.month, hoy.day) < (value.month, value.day))
    
    # Si la edad es mayor a 99, lanza una excepción
    if edad > 99:
        raise ValidationError('La persona no puede tener más de 99 años.')
    
def validar_nombre_largo(value):
    if len(value) < 3:
        raise ValidationError('El nombre debe tener al menos 3 caracteres.')
    if not value.isalpha():
        raise ValidationError('El nombre debe estar compuesto solamente por letras.')
    
    
def validar_apellido_minimo(value):
    if len(value.strip()) < 2:  # Verifica si el valor tiene al menos 1 carácter (ignora espacios en blanco)
        raise ValidationError('El apellido no puede estar vacío o tener menos de 2 carácteres.')
    if not value.isalpha():
        raise ValidationError('El apellido debe estar compuesto solamente por letras.')
