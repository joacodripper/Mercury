from django.apps import AppConfig


class MercuryConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mercury'

    def ready(self):
        import mercury.signals # Importa las señales al iniciar la aplicación