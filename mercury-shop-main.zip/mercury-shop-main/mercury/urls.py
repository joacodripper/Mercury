from django.urls import path
from . import views
from .views import *

app_name = 'mercury'

urlpatterns = [
    path('', views.index, name='Inicio'),
    path('register', views.register, name='Registro'),
    path('login', views.user_login, name="Iniciar sesión"),
    path('logout', views.user_logout, name="Cerrar sesión"),
    path('activate/<str:uidb64>/<str:token>', views.activate, name="activate"),
    path('ajax/get_provincias/', views.get_provincias, name='get_provincias'),
    path('ajax/get_comunas/', views.get_comunas, name='get_comunas'),
    path('debes-loguearte/', views.debes_loguearte, name='debes_loguearte'),

    path('home/', views.home, name='home'),
    path('about/', views.about, name='about'),

    # Inventario y productos

    path('productos/', ProductoListView.as_view(), name='listar_productos'),
    path('productos/crear/', ProductoCreateView.as_view(), name='crear_producto'),
    path('productos/editar/<int:pk>/', ProductoUpdateView.as_view(), name='editar_producto'),
    path('productos/eliminar/<int:producto_id>/', views.eliminar_producto, name='eliminar_producto'),
    path('productos/toggle_publicado/<int:producto_id>/', views.toggle_publicado, name='toggle_publicado'),
    path('productos/desactivar/<int:producto_id>/', views.desactivar_producto, name='desactivar_producto'),

    # Catálogo

    path('catalogo/', views.catalogo, name='catalogo'),
    path('producto/<int:product_id>/', views.producto_detalle, name='producto_detalle'),


    # Carrito de compras
    path('agregar_al_carrito/<int:producto_id>/', views.agregar_al_carrito, name='agregar_al_carrito'),
    path('carrito/sincronizar/', views.sincronizar_carrito, name='sincronizar_carrito'),
    path('carrito/cantidad/', views.cantidad_productos_carrito, name='cantidad_productos_carrito'),
    path('carrito/', views.vista_carrito, name='vista_carrito'),
    path('carrito/eliminar/<int:producto_carrito_id>/', views.eliminar_producto_carrito, name='eliminar_producto_carrito'),

    # Pago

    path('pago/iniciar/', views.iniciar_pago, name='iniciar_pago'),
    path('pago/confirmar/', views.confirmar_pago, name='confirmar_pago'),

    # Confirmar entrega

    path('venta/confirmar-entrega/', views.confirmar_entrega, name='confirmar_entrega'),

    # Reportes

    path('reportes/', reportes, name='reportes'),
    path('reportes/exportar/', views.exportar_datos, name='exportar_datos'),

    # Extra

    path('popularitems/', views.popularitems, name='popularitems'),
    path('newarrivals/', views.newarrivals, name='newarrivals'),

    
]
